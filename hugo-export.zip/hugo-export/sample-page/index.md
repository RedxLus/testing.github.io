---
title: Sample Page
author: redxlus
type: page
date: 2021-01-28T21:45:59+00:00

---
This is an example page. It&#8217;s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:

<blockquote class="wp-block-quote">
  <p>
    Hi there! I&#8217;m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin&#8217; caught in the rain.)
  </p>
</blockquote>

&#8230;or something like this:

<blockquote class="wp-block-quote">
  <p>
    The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.
  </p>
</blockquote>

As a new WordPress user, you should go to [your dashboard][1] to delete this page and create new pages for your content. Have fun!

 [1]: http://luisblog.local/wp-admin/