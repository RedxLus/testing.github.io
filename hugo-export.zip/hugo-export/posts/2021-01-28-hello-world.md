---
title: Hello world!
author: redxlus
type: post
date: 2021-01-28T21:45:59+00:00
url: /hello-world/
categories:
  - Uncategorized

---
Welcome to WordPress. This is your first post. Edit or delete it, then start writing!